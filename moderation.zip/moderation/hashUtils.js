/**
 * Image hash utilities for moderation
 * @module hashUtils
 */
const sharp = require('sharp');
const sharpPhash = require('sharp-phash');

/**
 * Generate perceptual hash (pHash) for an image buffer
 * @param {Buffer} buffer - Image buffer
 * @returns {Promise<string>} 64-bit pHash as string
 */
async function getPHash(buffer) {
  try {
    const phash = await sharpPhash(buffer);
    return phash;
  } catch (err) {
    throw new Error('pHash generation failed: ' + err.message);
  }
}

/**
 * Generate classic dHash (8x8, 64 bits) for an image buffer
 * @param {Buffer} buffer - Image buffer
 * @returns {Promise<string>} 64-bit dHash as string
 */
async function getDHash(buffer) {
  try {
    const { data } = await sharp(buffer)
      .grayscale()
      .resize(9, 8, { fit: 'fill' })
      .raw()
      .toBuffer({ resolveWithObject: true });
    let hash = '';
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const left = data[row * 9 + col];
        const right = data[row * 9 + col + 1];
        hash += left > right ? '1' : '0';
      }
    }
    return hash;
  } catch (err) {
    throw new Error('dHash generation failed: ' + err.message);
  }
}

module.exports = { getPHash, getDHash };

/**
 * Banned image hashes management
 * @module bannedHashes
 */
const Database = require('better-sqlite3');
const BKTree = require('bk-tree');
const path = require('path');
const dbPath = path.resolve(__dirname, '../data/banned_hashes.db');

// Initialize SQLite DB
const db = new Database(dbPath);
db.exec(`CREATE TABLE IF NOT EXISTS banned (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phash TEXT NOT NULL,
  dhash TEXT NOT NULL,
  reason TEXT,
  added_at TEXT DEFAULT CURRENT_TIMESTAMP
)`);

// Load all banned hashes
const bannedList = db.prepare('SELECT phash, dhash, reason FROM banned').all();

// Hamming distance function
/**
 * Calculate Hamming distance between two binary strings
 * @param {string} a
 * @param {string} b
 * @returns {number}
 */
function hammingDistance(a, b) {
  if (a.length !== b.length) return Infinity;
  let dist = 0;
  for (let i = 0; i < a.length; i++) {
    if (a[i] !== b[i]) dist++;
  }
  return dist;
}

// BK-tree setup
let phashTree, dhashTree;
try {
  phashTree = new BKTree(hammingDistance, bannedList.map(x => x.phash));
  dhashTree = new BKTree(hammingDistance, bannedList.map(x => x.dhash));
} catch (e) {
  // Fallback: brute-force
  phashTree = null;
  dhashTree = null;
}

/**
 * Check image hashes against banned list
 * @param {string} phash
 * @param {string} dhash
 * @returns {Promise<{banned: boolean, reason?: string, distance?: number}>}
 */
async function checkImageHashes(phash, dhash) {
  // Exact match
  for (const entry of bannedList) {
    if (phash === entry.phash || dhash === entry.dhash) {
      return { banned: true, reason: entry.reason, distance: 0 };
    }
  }

  // BK-tree or brute-force
  let minDist = Infinity, foundReason = undefined;
  let candidates = [];
  if (phashTree) {
    candidates = phashTree.search(phash, 14);
  } else {
    // Brute-force
    candidates = bannedList.map(x => ({ value: x.phash, reason: x.reason, dist: hammingDistance(phash, x.phash) })).filter(x => x.dist <= 14);
  }
  for (const c of candidates) {
    const dist = phashTree ? c.distance : c.dist;
    if (dist <= minDist) {
      minDist = dist;
      foundReason = c.reason;
    }
  }
  if (minDist <= 8) {
    return { banned: true, reason: foundReason, distance: minDist };
  } else if (minDist <= 14) {
    // Suspicious
    return { banned: false, reason: foundReason, distance: minDist };
  }

  // Repeat for dHash
  minDist = Infinity; foundReason = undefined;
  if (dhashTree) {
    candidates = dhashTree.search(dhash, 14);
  } else {
    candidates = bannedList.map(x => ({ value: x.dhash, reason: x.reason, dist: hammingDistance(dhash, x.dhash) })).filter(x => x.dist <= 14);
  }
  for (const c of candidates) {
    const dist = dhashTree ? c.distance : c.dist;
    if (dist <= minDist) {
      minDist = dist;
      foundReason = c.reason;
    }
  }
  if (minDist <= 8) {
    return { banned: true, reason: foundReason, distance: minDist };
  } else if (minDist <= 14) {
    return { banned: false, reason: foundReason, distance: minDist };
  }

  return { banned: false };
}

module.exports = { checkImageHashes, hammingDistance, bannedList, db };
